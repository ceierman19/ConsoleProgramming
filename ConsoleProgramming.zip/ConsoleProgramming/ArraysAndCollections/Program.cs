﻿using System;
using System.Collections.Generic;

namespace ArraysAndCollections
{
    internal class Program
    {
        static void Main(string[] args)
        {
            ///////////////////////////
            // Declare fixed size array
            /////////////////////////// 
            
            int[] grades = new int[5];  // 5 spaces means you have indexes 0, 1, 2, 3, 4
                                        // If n is the size of array, array indexes are 0 to n-1 


            ///////////////////////////////
            // Assign values to fixed array
            ///////////////////////////////
            
            // Hard-coding individually 
            //grades[0] = 1;
            //grades[1] = 12;
            //grades[2] = 13;
            //grades[3] = 90;
            //grades[4] = 54;

            // Hard-coding all at once 
            //grades = new int[] { 10, 20, 30, 40, 50 };

            // User Input 
            Console.WriteLine("Enter Student Grades");
            for (int i = 0; i < 5; i++)
            {
                Console.Write("Enter Grade: ");
                grades[i] = int.Parse(Console.ReadLine());
            }

            
            //////////////////////////////
            // Print values in fixed array
            //////////////////////////////
            
            Console.WriteLine("Grades Entered: ");
            for (int i = 0; i < 5; i++)
            {
                Console.WriteLine(grades[i]);
            }
            Console.WriteLine();

            
            
            //////////////////////////////
            // Declare variable size array
            //////////////////////////////
            
            int[] grades1;


            //////////////////////////////////
            // Assign values to variable array 
            //////////////////////////////////
            
            grades1 = new int[] { 10, 20, 30, 40, 50, 60, 70, 80, 90, 100 };


            /////////////////////////////////
            // Print values in variable array
            /////////////////////////////////
            
            Console.WriteLine("Grades Entered: ");
            for (int i = 0; i < grades1.Length; i++)
            {
                Console.WriteLine(grades1[i]);
            }
            Console.WriteLine();


            
            /////////////////
            // Declare a list 
            /////////////////
            
            List<string> names = new List<string>();
            string name = "";

            
            /////////////////////
            // Add values to list
            /////////////////////
            
            names.Add("Carrie");
            Console.WriteLine("Enter Names: ");
            while (!name.Equals("-1"))
            {
                name = Console.ReadLine();
                if (!name.Equals("-1")) 
                {
                    names.Add(name);
                }
            }
            Console.WriteLine();


            ///////////////////////
            // Print values in list 
            ///////////////////////
            
            // Using for loop 
            Console.WriteLine("Names Entered (for loop): ");
            for (int i = 0; i < names.Count; i++)
            {
                Console.WriteLine(names[i]);
            }
            Console.WriteLine(); 

            // Using foreach loop 
            Console.WriteLine("Names Entered (foreach loop): ");
            foreach (string item in names)
            {
                Console.WriteLine(item);
            }
        }
    }
}
