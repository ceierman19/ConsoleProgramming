﻿using System;

namespace CSharpOperators
{
    internal class Program
    {
        static void Main(string[] args)
        {
            // Basic Assignment Operator 
            int num;
            num = 5; 
            Console.WriteLine($"Assigned Value to Variable {num}");

            
            // Arithmetic Operators 
            int x = 11;
            int y = 3;

            Console.WriteLine($"Addition: {x + y}");
            Console.WriteLine($"Subtraction: {x - y}");
            Console.WriteLine($"Multiplication: {x * y}");
            Console.WriteLine($"Division: {x / y}");
            Console.WriteLine($"Modulus: {x % y}");  // remainder of a division 

            
            // Assigning a new value to x 
            x = x + 4;
            
            Console.WriteLine($"New Value of x: {x}");
            Console.WriteLine($"Addition: {x + y}");
            Console.WriteLine($"Subtraction: {x - y}");
            Console.WriteLine($"Multiplication: {x * y}");
            Console.WriteLine($"Division: {x / y}");
            Console.WriteLine($"Modulus: {x % y}");

            
            // Compound Assignment Operators 
            x += 5;  // x = x + 4; 
            Console.WriteLine(x);
            x -= 3;
            Console.WriteLine(x);
            x *= 2;
            Console.WriteLine(x);
            x /= 3;
            Console.WriteLine(x);
            x %= 3;
            Console.WriteLine(x); 

            // x changes based on its most recently stored value 
        }
    }
}
