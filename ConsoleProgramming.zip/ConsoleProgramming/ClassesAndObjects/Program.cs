﻿using System;

namespace ClassesAndObjects
{
    internal class Program
    {
        static void Main(string[] args)
        {
            // Base variable and datatype declaration 
            int num = 0; 

            
            ///////////////////////////////////
            // Create Objects of Class Type Box
            ///////////////////////////////////
            
            Box box = new Box();
            Box box2 = new Box();

            
            // Receiving input for Box 1 
            Console.WriteLine("Enter length for Box 1: ");
            double n1 = double.Parse(Console.ReadLine());
            Console.WriteLine("Enter breadth for Box 1: ");
            double n2 = double.Parse(Console.ReadLine());
            Console.WriteLine("Enter height for Box 1: ");
            double n3 = double.Parse(Console.ReadLine());
            Console.WriteLine();

            
            // Setting values in object properties 
            box.Length = n1; 
            box.Breadth = n2;
            box.Height = n3;
            double volume = box.getVolume();
            double area = box.getArea();

            
            // Receiving input for Box 2 
            Console.WriteLine("Enter length for Box 2: ");
            n1 = double.Parse(Console.ReadLine());
            Console.WriteLine("Enter breadth for Box 2: ");
            n2 = double.Parse(Console.ReadLine());
            Console.WriteLine("Enter height for Box 2: ");
            n3 = double.Parse(Console.ReadLine());
            Console.WriteLine();

            
            // Setting values in object properties 
            box2.Length = n1;
            box2.Breadth = n2;
            box2.Height = n3;


            // Getting values from object properties 
            Console.WriteLine($"Box 1 Dimensions Are: {box.Length}, {box.Breadth}, {box.Height}");
            Console.WriteLine($"Box 1 Volume Is: {volume}");
            Console.WriteLine($"Box 1 Area Is: {area}");
            Console.WriteLine();

            Console.WriteLine($"Box 2 Dimensions Are: {box2.Length}, {box2.Breadth}, {box2.Height}");
            Console.WriteLine($"Box 2 Volume Is: {box2.getVolume()}");
            Console.WriteLine($"Box 2 Area Is: {box2.getArea()}");
            Console.WriteLine();


            
            //////////////////////////////
            // Object of Class Type Person
            //////////////////////////////
            
            Person person = new Person();
            person.FirstName = "Carrie";
            person.LastName = "Eierman";
            Console.WriteLine($"Full Name Is: {person.getFullName()}"); 
            // ... 
        }
    }
}
