﻿using System;

namespace ConditionalStatements
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int num1 = 0;
            int num2 = 0;
            int num3 = 0;
            string result;

            Console.Write("How many apples do you have? ");
            num1 = Convert.ToInt32(Console.ReadLine());

            Console.Write("How many oranges do you have? ");
            num2 = Convert.ToInt32(Console.ReadLine());



            ////////////////
            // IF Statements
            ////////////////

            // Comparison Operators: <, >, ==, <=, >=, !=

            if (num2 > num1)
            {
                Console.WriteLine("You have more oranges!");
            }
            else if (num1 > num2)
            {
                Console.WriteLine("You have more apples!");
            }
            else if (num1 == num2)
            {
                Console.WriteLine("You have the same number of apples and oranges!");
            }
            else
            {
                Console.WriteLine("Invalid parameters");
            }

            
            // To comment out selected lines of code all at once, use ctrl + k + c 
            // Uncomment using ctrl + k + u

            
            Console.Write("How many eyes do you have? ");
            num3 = Convert.ToInt32(Console.ReadLine());
            
            ////////////////////
            // Switch Statements
            ////////////////////
            
            switch (num3)
            {
                case 1:
                    Console.WriteLine("You have 1 eye");
                    break;

                case 2:
                    Console.WriteLine("You have 2 eyes");
                    Console.WriteLine("You can have multiple lines...");
                    Console.WriteLine("...within each case"); 
                    Console.WriteLine("Just make sure to put the break keyword");
                    break;
                default:
                    Console.WriteLine("Invalid value");
                    break;
            }

            

            /////////////////////
            // Ternary Statements
            /////////////////////
            
            result = (num2 > num1) ? "You have more oranges" : "You have more apples"; 
            // If num2 > num1, assign the first value to result
            // Otherwise, assign the second value to result 
            // Mini if/else statement 
        }
    }
}
