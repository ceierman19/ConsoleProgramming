﻿using System;

namespace ExceptionHandling
{
    internal class Program
    {
        static void Main(string[] args)
        {
            /* 
             * try - A try block identifies a block of code for which particular exceptions are activated 
             * catch - A program catches an exception with an exception handler 
             * finally - The finally block is used to execute, regardless of whether an exception is thrown 
             * throw - A program throws an exception when a problem shows up 
             */

            Console.WriteLine("Enter first number: "); 
            int n1 = int.Parse(Console.ReadLine());

            Console.WriteLine("Enter second number: ");
            int n2 = int.Parse(Console.ReadLine());

            //int result = n1 / n2;
            //Console.WriteLine($"Result: {result}");

            
            // Handling the exception of dividing by zero 
            try
            {
                int result = n1 / n2;
                Console.WriteLine($"Result: {result}");
            }
            catch (Exception e)
            {
                //throw;
                Console.WriteLine($"Illegal operation: {e.Message}");
            }
            finally
            {
                Console.WriteLine("End of Program"); 
            }
        }
    }
}
