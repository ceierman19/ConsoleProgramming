﻿using System;

namespace HelloWorld
{
    internal class Program
    {
        static void Main(string[] args)
        {
            // Printing to Console Screen 
            Console.WriteLine("Hello World!");

            
            /* 
             * Commenting 
             * Paragraphs 
             */
        }
    }
}