﻿using System;

namespace InputOutput
{
    internal class Program
    {
        static void Main(string[] args)
        {
            // Declare variables 
            string name;

            
            // Get and store value from input 
            Console.WriteLine("Please Enter Your Name: ");
            name = Console.ReadLine();

            
            // Print value(s) to console screen 
            Console.Write("Your Name Is: ");  // Write vs WriteLine = single line vs new line 
            Console.WriteLine(name); 
        }
    }
}
