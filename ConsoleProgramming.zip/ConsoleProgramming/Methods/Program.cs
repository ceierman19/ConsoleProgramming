﻿using System;

namespace Methods
{
    internal class Program
    {
        ////////////////////////////////////////////////
        // Void Functions (Declarations and Definitions)
        ////////////////////////////////////////////////
        
        static void PrintName()
        {
            Console.WriteLine("Carrie Eierman");
        }
        
        static void PrintName(string name)  // Function Overloading 
        {
            Console.WriteLine(name.ToUpper());
        }

        static void PrintNameLowerCase(string name)
        {
            Console.WriteLine(name.ToLower());
        }


        
        ////////////////////////////////////////////////////////
        // Value Returning Function (Declaration and Definition)
        ////////////////////////////////////////////////////////
        
        static int Max(int num1, int num2, int num3)
        {
            int max = num1;
            
            if (num2 > max)
            {
                max = num2;
            }
            if (num3 > max)
            {
                max = num3;
            }

            return max;
        }

        

        ////////////////
        // Main Function
        ////////////////
        
        static void Main(string[] args)
        {
            // Call Void Functions 
            PrintName();
            Console.WriteLine("End Name Function");
            Console.WriteLine();

            Console.WriteLine("Enter Your Name: ");
            string n = Console.ReadLine();
            PrintName(n);
            Console.WriteLine("End Upper Case Name Function");
            PrintNameLowerCase(n);
            Console.WriteLine("End Lower Case Name Function");
            Console.WriteLine();


            // Call Value Returning Function  
            Console.WriteLine("Enter first number: ");
            int n1 = int.Parse(Console.ReadLine());
            Console.WriteLine("Enter second number: ");
            int n2 = int.Parse(Console.ReadLine());
            Console.WriteLine("Enter third number: "); 
            int n3 = int.Parse(Console.ReadLine());

            int result = Max(n1, n2, n3);
            Console.WriteLine($"Largest Number: {result}");
        }
    }
}
