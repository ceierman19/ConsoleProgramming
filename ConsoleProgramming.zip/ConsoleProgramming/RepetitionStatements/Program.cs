﻿using System;

namespace RepetitionStatements
{
    internal class Program
    {
        static void Main(string[] args)
        {
            ///////////////////////////////////////////////////
            // For Loop (Counter Controlled) - Printing 5 times
            ///////////////////////////////////////////////////
            
            for (int i = 0; i < 5; i++)  // for(int i = 1; i <= 5; i++)
            {
                Console.WriteLine("INSIDE FOR LOOP");
                Console.WriteLine($"Counter/Iteration: {i}");
            }
            Console.WriteLine("FOR LOOP FINISHED");
            Console.WriteLine();  // Good way to separate sections w/ blank space 


            
            ////////////////////////////////////////////////
            // While Loop (Condition Controlled - Pre Check)
            ////////////////////////////////////////////////
            
            int n = 0;

            //while(n == 0)  // infinite loop 
            //{
            //    Console.WriteLine("INSIDE WHILE LOOP");
            //    Console.WriteLine();
            //}

            while (n < 5)
            {
                Console.WriteLine("INSIDE WHILE LOOP");
                n++;  // increment variable w/ an accumulator   n = n + 1   or   n += 1 
            }
            Console.WriteLine("WHILE LOOP FINISHED");
            Console.WriteLine(); 

            n = 10;
            
            while (n < 5)
            {
                Console.WriteLine("Input a number from 0-4: "); 
                n = Convert.ToInt32(Console.ReadLine());
                Console.WriteLine($"You entered {n}");
            }
            Console.WriteLine("WHILE LOOP FINISHED");
            Console.WriteLine();
            // Prints WHILE LOOP FINISHED b/c the value of n was changed to 10, which is > 5


            
            //////////////////////////////////////////////////////
            // Do...While Loop (Condition Controlled - Post Check)
            //////////////////////////////////////////////////////
            
            // Ensures something happens at least once 
            
            do
            {
                Console.WriteLine("Input a number from 0-4: ");
                n = Convert.ToInt32(Console.ReadLine());
                Console.WriteLine($"You entered {n}");
            } while (n < 5);
            Console.WriteLine();
            Console.WriteLine("DO WHILE LOOP FINISHED");
        }
    }
}
