﻿using System;

namespace StringManipulation
{
    internal class Program
    {
        static void Main(string[] args)
        {
            ////////////////////////////
            // Declare a string variable
            ////////////////////////////
            
            string fullName = "Hi, my name is Carrie Eierman";
            string firstName = "Carrie";
            string lastName = "Eierman";

            

            //////////////////
            // Print to screen
            //////////////////
            
            Console.WriteLine(fullName);
            Console.WriteLine();

            
            
            ////////////////
            // Concatenation
            ////////////////
            
            Console.WriteLine("My Full Name Is: " + firstName + " " + lastName);
            Console.WriteLine("My Full Name Is: {0} {1}", firstName, lastName);  // placeholders
            Console.WriteLine($"My Full Name Is: {firstName} {lastName}");  // interpolation 
            Console.WriteLine();

            

            /////////////////////////
            // Count length of string
            /////////////////////////
            
            int length = firstName.Length; 
            Console.WriteLine(length);

            int length1 = fullName.Length;
            Console.WriteLine(length1);  // everything in quotation marks is included in string length 
            Console.WriteLine();
            
            
            
            ////////////////////////// 
            // Replace parts of string
            //////////////////////////
            
            string newName = firstName.Replace('e', 'S');  // any singular char (letter, symbol, space, num)
            Console.WriteLine(newName);

            string newName1 = firstName.Replace('r', 's');
            Console.WriteLine(newName1);
            Console.WriteLine();

            

            // Append to existing string 
            // String splits 



            //////////////////
            // Compare Strings
            //////////////////
            
            // Compare strings with if/else
            if (firstName == lastName)
            {
                Console.WriteLine("You have the same first and last names");
            }
            else
            {
                Console.WriteLine("You have different first and last names");
            }


            // Compare strings using Compare method/function
            int result = string.Compare(firstName, lastName);
            if (result == 0)
            {
                Console.WriteLine("You have the same first and last names");
            }
            else  // result == 1 or -1 
            {
                Console.WriteLine("You have different first and last names");
            }

            Console.WriteLine();

            

            ////////////////////
            // Convert to string
            ////////////////////
            
            result = 123456789;
            string bigNumber = result.ToString();
            Console.WriteLine("My Bank Balance Is: " + bigNumber); 
        }
    }
}
