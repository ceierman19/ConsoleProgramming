﻿using System;

namespace VariablesAndDataTypes
{
    internal class Program
    {
        static void Main(string[] args)
        {
            // Declare variables and types 
            string name;
            int age;
            double salary;  // double is more precise than float 
            char gender;
            bool working;

            
            // Prompt users for input 
            Console.Write("Enter Your Name: ");
            name = Console.ReadLine();

            Console.Write("Enter Your Age: ");
            age = Convert.ToInt32(Console.ReadLine());

            Console.Write("Enter You Salary: "); 
            salary = Convert.ToDouble(Console.ReadLine());

            Console.Write("Enter Your Gender (M/F/O): "); 
            gender = Convert.ToChar(Console.ReadLine());

            Console.Write("Enter Whether You Are Working (True/False): ");
            working = Convert.ToBoolean(Console.ReadLine());
            Console.WriteLine();

            
            // Print to screen 
            Console.WriteLine("Your Name Is: " + name);  // concatenation 
            Console.WriteLine("Your Age Is:  {0}", age);  // placeholders 
            Console.WriteLine($"Your Salary Is: {salary}");  // interpolation 
            Console.WriteLine("Your Gender Is: " + gender);
            Console.WriteLine("You are Employed: " + working);
            Console.WriteLine();


            // Print size of datatypes 
            Console.WriteLine($"Size of Int: {sizeof(int)}");
        }
    }
}
